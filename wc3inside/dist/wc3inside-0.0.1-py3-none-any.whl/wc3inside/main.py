# Dependancy for https://hub.docker.com/r/tiangolo/uwsgi-nginx-flask/

from wc3inside.srv import serv

app = serv.app
