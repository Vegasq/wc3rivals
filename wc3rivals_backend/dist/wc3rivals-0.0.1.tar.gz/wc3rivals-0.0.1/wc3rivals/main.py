# Dependancy for https://hub.docker.com/r/tiangolo/uwsgi-nginx-flask/

from wc3rivals import serv

app = serv.app
