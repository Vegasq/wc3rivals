from wc3rivals.utils import db
from wc3rivals.utils.log import LOG

from pymongo import TEXT
from pymongo import errors
from bson.code import Code


ladders = ["Lordaeron", "Azeroth", "Northrend"]


def index_usernames_db():
    """This index used in Header.vue to earch for usernames"""
    for l in ladders:
        usernames = db.UsernamesDB(l)
        col = usernames.collection_usernames
        if "value_text" not in col.index_information().keys():
            col.create_index('value')


def index_history_db():
    for l in ladders:
        usernames = db.HistoryDB(l)
        col = usernames.collection_usernames
        if "value_text" not in col.index_information().keys():
            col.create_index('value')


def up():
    index_usernames_db()


if __name__ == "__main__":
    up()
